package com.njuyuh.werdrs.asdxvz;




public interface Lnvaowiehoberb {
    void onSafe(boolean aowejovawreb, String awejboijawrbe);

    void onSafeXq(boolean awejvoiaweb, String awenvaiwerb);
}
