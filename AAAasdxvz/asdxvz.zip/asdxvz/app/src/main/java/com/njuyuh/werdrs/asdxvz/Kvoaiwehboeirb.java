package com.njuyuh.werdrs.asdxvz;



public interface Kvoaiwehboeirb {

    void awembvajwreobi(boolean awejobviawrbe, String  vawneroib);

    void ajweoihberio();
}
