package com.njuyuh.werdrs.asdxvz;

public class Acnaiowehboeirb {
    public Acnaiowehboeirb(int awenvoaiwerb, boolean awemvboierb, int vwajeoirber) {
        this.vaweiobre = awenvoaiwerb;
        this.aowejhoaierb = awemvboierb;
        this.vaweoibher = vwajeoirber;
    }


    private int vaweiobre;
    private boolean aowejhoaierb;

    public int vnawoierhboerb() {
        return vaweoibher;
    }

    public void awejvoiawerb(int vnawoeirhb) {
        this.vaweoibher = vnawoeirhb;
    }

    private int vaweoibher;

    public Acnaiowehboeirb(int awejgoierb, boolean vmawioebheorb) {
        this.vaweiobre = awejgoierb;
        this.aowejhoaierb = vmawioebheorb;
    }

    public int vmwneoibherb() {
        return vaweiobre;
    }

    public void awejgawoeirb(int vawejoierb) {
        this.vaweiobre = vawejoierb;
    }

    public boolean vawejosireb() {
        return aowejhoaierb;
    }

    public void vaweoibherb(boolean awejoivahoewrb) {
        this.aowejhoaierb = awejoivahoewrb;
    }

}
