package com.njuyuh.werdrs.asdxvz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import hhfgfdaa.ttredbb.ssswercc.nnbvxccdda.R;


public class Dncaewhvobierb extends Activity {

    @Override
    protected void onCreate(Bundle vawenoivhaweorb) {
        super.onCreate(vawenoivhaweorb);
        awenvioawherbo();
        Lnvaowiehoberb gjhoiw = new Lnvaowiehoberb() {
            @Override
            public void onSafe(boolean aowejovawreb, String awejboijawrbe) {

            }

            @Override
            public void onSafeXq(boolean awejvoiaweb, String errMsg) {

            }
        };
    }

    private void awenvioawherbo() {
        awegvnioawerhbo();
        awejojvahweirb();
    }

    private void awegvnioawerhbo() {
        setContentView(R.layout.caweiovhaerbo);
    }
    private void awejojvahweirb() {
        kjawoiehesbr();
    }

    private void kjawoiehesbr() {
        findViewById(R.id.vmawoieshvoerb).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View oawjefhoaiwehrb) {
                vawemoivbahewrb();
            }
        });
    }
    private void vawemoivbahewrb(){
        startActivity(new Intent(getApplicationContext(), Cmaweoibeosrb.class));
    }
}