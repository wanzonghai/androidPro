package com.njuyuh.werdrs.asdxvz;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;


public class Svnaeorihbioesrnb extends View {
    public Svnaeorihbioesrnb(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public Svnaeorihbioesrnb(Context context) {
        super(context);
    }
}
