package com.njuyuh.werdrs.asdxvz;

import java.util.List;

public class Fnvawoiehberb {

    private int awejbvoiajweroib;
    private String awegvoiawehrbo;
    private List<String> awjoeigjaoerb;

    public Double getHawiehgr() {
        return hawiehgr;
    }

    public void setHawiehgr(Double hawiehgr) {
        this.hawiehgr = hawiehgr;
    }

    private Double hawiehgr;

    public int getAwejbvoiajweroib() {
        return awejbvoiajweroib;
    }

    public void setAwejbvoiajweroib(int State) {
        this.awejbvoiajweroib = State;
    }

    public String getAwegvoiawehrbo() {
        return awegvoiawehrbo;
    }

    public void setAwegvoiawehrbo(String Message) {
        this.awegvoiawehrbo = Message;
    }

    public List<String> getAwjoeigjaoerb() {
        return awjoeigjaoerb;
    }

    public void setAwjoeigjaoerb(List<String> Data) {
        this.awjoeigjaoerb = Data;
    }
}
