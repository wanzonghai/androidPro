package com.testtest.testttt;

public class TestHttpUriData {
    String mjfduuyrtegfd = "";

    public TestHttpUriData(String asd) {
        this.mjfduuyrtegfd = asd;
    }
}
